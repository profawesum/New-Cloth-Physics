//#include "Cloth.h"
//#include "glm.hpp"
//
//Constraint::Constraint(Particle *p1, Particle *p2) {
//	Vec3 vec = p1->getPos() - p2->getPos();
//	restDistance = vec.length();
//}
//
//void Constraint::satisfyConstraint() {
//
//	Vec3 p1Top2 = p2->getPos() - p1->getPos();
//
//}