#include <glut.h> 
#include <math.h>
#include <vector>
#include <iostream>
#include <glm.hpp>

#include "Cloth.h"

using namespace glm;

#define TIME_STEPSIZE2 0.5f*0.5f

Cloth* cloth1 = new Cloth(14, 10, 55, 45);
Vec3 ball_pos(7, -5, 0);
float ball_radius = 2;

bool ballCollision;
bool ballMove;
bool addForce;
bool addWind;

Vec3 floorPos(8, -70, 4);
float floorRadius = 55;

float ball_time = 0;

void render()
{
	glEnable(GL_DEPTH_TEST);

	ball_time++;

	if (ballMove) {
		ball_pos.f[2] = cos(ball_time / 50.0) * 7;
	}
	if (addForce) {
		cloth1->addForce(Vec3(0, -0.2f, 0)*TIME_STEPSIZE2);
	}
	if (addWind) {
		cloth1->windForce(Vec3(0.5f, 0, 0.2f)*TIME_STEPSIZE2);
	}

	cloth1->timeStep();

	if (ballCollision) {
		cloth1->ballCollision(ball_pos, ball_radius);
	}
	cloth1->ballCollision(floorPos, floorRadius);

	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glLoadIdentity();

	glTranslatef(-6.5, 6, -9.0f);
	glRotatef(25, 0, 1, 0);
	cloth1->drawShaded();

	glPushMatrix();
	glTranslatef(floorPos.f[0], floorPos.f[1], floorPos.f[2]);
	glColor3f(0.4f, 0.8f, 0.5f);
	glutSolidSphere(floorRadius - 0.1, 50, 50);
	glPopMatrix();

	glPushMatrix();
	glTranslatef(ball_pos.f[0], ball_pos.f[1], ball_pos.f[2]);
	glColor3f(0.4f, 0.8f, 0.5f);
	glutSolidSphere(ball_radius - 0.1, 50, 50);
	glPopMatrix();

	glutSwapBuffers();
	glutPostRedisplay();
}

void reshape(int w, int h)
{
	glViewport(0, 0, w, h);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	if (h == 0)
		gluPerspective(80, (float)w, 1.0, 5000.0);
	else
		gluPerspective(80, (float)w / (float)h, 1.0, 5000.0);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
}

void keyboard(unsigned char key, int x, int y)
{
	switch (key) {
	//the user presses escape and the application will quit
	case 27:
		exit(0);
		break;
	//the user presses e and the cloth will drop
	case 101:
		cloth1->dropCloth();
		break;
	case 99:
		ballCollision = !ballCollision;
		break;
		//r
	case 114:
		ballMove = !ballMove;
		break;
		//a
	case 97:
		addForce = !addForce;
		break;
		//b
	case 98:
		addWind = !addWind;
		break;
	default:
		break;
	}
}

int main(int argc, char** argv)
{
	glutInit(&argc, argv);

	glutInitDisplayMode(GLUT_RGB | GLUT_DOUBLE | GLUT_DEPTH);
	glutInitWindowSize(1280, 720);

	glutCreateWindow("Cloth Simulation");
	glutDisplayFunc(render);
	glutReshapeFunc(reshape);
	glutKeyboardFunc(keyboard);

	glutMainLoop();
}