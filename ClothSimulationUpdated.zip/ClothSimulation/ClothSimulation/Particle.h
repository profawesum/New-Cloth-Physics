//
////lib includes
//#include <glut.h> 
//#include <math.h>
//#include <vector>
//#include <iostream>
//#include "glm.hpp"
//
//using namespace glm;
//
////class Particle{
////
////public:
////
////	bool movable;
////	float mass;
////
////	Vec3 pos;
////	Vec3 oldPos;
////	Vec3 acceleration;
////	Vec3 accumulatedNormal;
////
////	//constructor
////	Particle(Vec3 pos) : pos(pos), oldPos(pos), acceleration(Vec3(0, 0, 0)), mass(1), movable(true), accumulatedNormal(Vec3(0, 0, 0)) {}
////	Particle() {}
////
////	Vec3& getPos() { return pos; }
////
////	void addForce(Vec3 f) { acceleration += f / mass; }
////
////	void resetAcceleration() { acceleration = Vec3(0, 0, 0); }
////
////	void offsetPos(const Vec3 v) { if (movable) pos += v; }
////
////	void makeUnmovable() { movable = false; }
////
////	void addToNormal(Vec3 normal) { accumulatedNormal += normalize(normal); }
////
////	Vec3 getNormal() { return accumulatedNormal; }
////	
////	void resetNormal() { accumulatedNormal = Vec3(0, 0, 0); }
////
////	void timeStep();
////
////};
////
////extern float Damping;
////extern float TimeStepSize;
////extern float ConstraintIterations;